library(ggplot2)

library(markovchain)
library(reshape2)
library(dplyr)

rm(list=ls())
graphics.off()

my.d <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(my.d)

source('fcts/Fct_Simulate_BAR.R')
source('fcts/Fct_Create_FinancialHistory.R')
source('fcts/Fct_Estimate_BaR.R')

l.in <- list()

n.sim <- 1000
n.T <- 2*12
bal.0 <- 1000
diff.E <- 400
diff.E2 <- 200

set.seed(seed = 15)

# FI <- 3000
# MI <-    c(rep(200,5),FI*0.5,rep(100,5),FI*(0.5 + 1/3) )
# MI_se <- rep(50,12)
# 
# FE <- 2750
# ME <-    c(rep(200,5),0.3*FE,rep(100,5), 0.3*FE)
# ME_se <- rep(150,12)


B.0 <- 1000
FI <- 3050
MI <-    c(rep(0,5),
           FI*0.5,
           rep(0,5),
           FI*(0.5) )
MI_se <- rep(50,12)

FE <- 3000
ME <-    c(rep(0,5),
           0.40*FE, 
           rep(0,5), 
           0.40*FE)
ME_se <- rep(250,12)

n.T.FinHistory <- 5*12

#df <- CreateFinHistory(n.T.FinHistory, bal.0, FI,MI,MI_se,FE,ME,ME_SE)
df <- read.csv(file = 'SimData.csv')

library(reshape)
df.melted <- melt(df, id.vars = 'Time', measure.vars = c('Income','Expenses','Balance') )

df.melted <- subset(df.melted,variable!='Balance' )


i.m <- df$i.m
Income <- df$Income
Expenses <- df$Expenses
tEmployment <- 3*12
t_no_Employment <- 3

l.in <- EstimateBAR(i.m, Income,Expenses,tEmployment,t_no_Employment )

l.in$bal.0 <- bal.0

poup.mat1 <- Simulate_BAR(n.sim = n.sim,
                         n.T = n.T,
                         list.in = l.in)


# resimulate with interest

l.in2 <- l.in
l.in2$my.m.E$coefficients[1] <- l.in2$my.m.E$coefficients[1] + diff.E
poup.mat2 <- Simulate_BAR(n.sim = n.sim,
                          n.T = n.T,
                          list.in = l.in2)

l.in3 <- l.in
l.in3$my.m.E$coefficients[1] <- l.in3$my.m.E$coefficients[1] + diff.E2
poup.mat3 <- Simulate_BAR(n.sim = n.sim,
                          n.T = n.T,
                          list.in = l.in3)

default.cases1<- rowMeans(matrix(as.numeric(poup.mat1[-1, ]<=0),nrow = n.T ))
default.cases2<- rowMeans(matrix(as.numeric(poup.mat2[-1, ]<=0),nrow = n.T ))
default.cases3<- rowMeans(matrix(as.numeric(poup.mat3[-1, ]<=0),nrow = n.T ))

# prob of default

df <- data.frame(default.cases1 = default.cases1, default.cases2 = default.cases2, default.cases3 = default.cases3,
                 x = 1:n.T)

df <- melt(df, id.vars = 'x')


library(reshape)

x11()
p<- ggplot(data = df, aes(x =x, y = value, linetype = variable ))
p <- p + geom_line(size=2) + labs(x = 'Months', y = 'Probability of Default')
p <- p + scale_linetype_discrete(name = NULL, labels = c('Default prob. (without loan)',
                                                       paste('DP with', diff.E , 'per month loan'),
                                                       paste('DP with', diff.E2, 'per month loan')))
p <- p + scale_x_continuous(breaks = seq(0, max(df$x), by = 6)) 
p <- p + theme(legend.position="bottom")  
#p <- p + scale_y_continuous(limits = c(0,1))
print(p)


f.name <- 'figs/Fig_EffectDebt2.png'
ggsave(filename = f.name)

temp.df  <- subset(df, variable=='default.cases1' )

x11()
p<- ggplot(data = temp.df , aes(x =x, y = value, linetype = variable ))
p <- p + geom_line(size=2) + labs(x = 'Months', y = 'Probability of Default')
p <- p + scale_linetype_discrete(name = NULL, labels = c('Default prob. (without loan)'))
p <- p + scale_x_continuous(breaks = seq(0, max(temp.df$x), by = 6)) 
p <- p + theme(legend.position="bottom")  
#p <- p + scale_y_continuous(limits = c(0,1))
print(p)

f.name <- 'figs/Fig_DefaultProbability.png'
ggsave(filename = f.name)

# calculate risk measures

temp.df <-  filter(df, variable == 'default.cases1')
LGD.case.1 <- sum(temp.df$value*diff.E)


l.in3 <- l.in
l.in3$my.m.E$coefficients[1] <- l.in3$my.m.E$coefficients[1] + diff.E2
n.T = 4*12
poup.mat3 <- Simulate_BAR(n.sim = n.sim,
                          n.T = n.T ,
                          list.in = l.in3)

default.cases4<- rowMeans(matrix(as.numeric(poup.mat3[-1, ]<=0),nrow = n.T ))
LGD.case.2 <- sum(default.cases3*diff.E2)

