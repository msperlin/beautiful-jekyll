library(ggplot2)

rm(list=ls())
graphics.off()

my.d <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(my.d)
source('Fct_Create_FinancialHistory.R')

n.T <- 5*12   # number of time periods

B.0 <- 1000
FI <- 3000
MI <-    c(rep(200,5),FI*0.5,rep(100,5),FI*(0.5 + 1/3) )
MI_se <- rep(50,12)

FE <- 2950
ME <-    c(rep(200,5),0.5*FE,rep(100,5), 0.5*FE)
ME_se <- rep(350,12)

set.seed(seed = 10)

df <- CreateFinHistory(n.T, B.0, FI,MI,MI_se,FE,ME,ME_SE)

write.csv(x = df, file = 'SimData.csv')

x11()
p <- ggplot(df, aes(x=Time, y=Balance)) + geom_line()
print(p)

library(reshape)
df <- melt(df, id.vars = 'Time', measure.vars = c('Income','Expenses','Balance') )

#df <- 

x11()
p <- ggplot(subset(df,variable!='Balance' ), aes(x=Time, y=value, linetype=variable)) + geom_line(size=1.5)
p <- p + labs('x = Time (months)') +  scale_linetype_discrete(name = NULL, labels = c('Simulated income','Simulated expenses' ))
p <- p + theme(legend.position=c(0.2,0.9)) #+ theme_classic() 
print(p)

x11()
p <- ggplot(df, aes(x=Time, y=value)) + geom_line(size=1)
p <- p + labs(x = 'Time (months)') #+  scale_linetype_discrete(name = NULL, labels = c('Simulated income','Simulated expenses' ))
p <- p + theme(legend.position=c(0.2,0.9)) #+ theme_classic() 
p <- p + facet_wrap(~variable)
print(p)


ggsave(filename = 'Fig_SimulatedIncomeExpense.png')

