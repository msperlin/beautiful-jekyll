library(ggplot2)

rm(list=ls())
graphics.off()

my.d <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(my.d)
source('fcts/Fct_Create_FinancialHistory.R')

n.T <- 5*12   # number of time periods

B.0 <- 1000
FI <- 3050
MI <-    c(rep(0, 5),
           FI*0.5,
           rep(0,5),
           FI*(0.5) )
MI_se <- rep(50,12)

FE <- 3000
ME <-    c(rep(0,5),
           0.40*FE, 
           rep(0,5), 
           0.40*FE)
ME_se <- rep(250,12)

set.seed(seed = 10)

df <- CreateFinHistory(n.T, B.0, FI,MI,MI_se,FE,ME,ME_SE)

write.csv(x = df, file = 'SimData.csv')

x11()
p <- ggplot(df, aes(x=Time, y=Balance)) + geom_line()
print(p)

library(reshape)
df <- melt(df, id.vars = 'Time', measure.vars = c('Income','Expenses','Balance') )

#df <- 

x11()
p <- ggplot(subset(df,variable!='Balance' ), aes(x=Time, y=value, linetype=variable)) + geom_line(size=1.5)
p <- p + labs('x = Time (months)') +  scale_linetype_discrete(name = NULL, labels = c('Simulated income','Simulated expenses' ))
p <- p + theme(legend.position=c(0.2,0.9)) #+ theme_classic() 
print(p)

x11()
p <- ggplot(df, aes(x=Time, y=value)) + geom_line(size=1)
p <- p + labs(x = 'Time (months)') #+  scale_linetype_discrete(name = NULL, labels = c('Simulated income','Simulated expenses' ))
p <- p + theme(legend.position=c(0.2,0.9)) #+ theme_classic() 
p <- p + facet_wrap(~variable, nrow = 3, scales = 'free_y') 
p <- p + scale_x_continuous(breaks = seq(0, max(df$Time), by = 6)) 
print(p)


ggsave(filename = 'figs/Fig_SimulatedIncomeExpense.png')

