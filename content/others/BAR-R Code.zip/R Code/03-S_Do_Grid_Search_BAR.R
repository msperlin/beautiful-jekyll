library(ggplot2)
library(dummies)
library(markovchain)
library(reshape2)
library(dplyr)
library(doParallel)

rm(list=ls())
my.f <- dir(path = 'TxtOut', pattern = '*.csv', full.names = T)
file.remove(my.f)

graphics.off()

my.d <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(my.d)

source('fcts/Fct_Simulate_BAR.R')
source('fcts/Fct_Create_FinancialHistory.R')
source('fcts/Fct_Estimate_BaR.R')

l.in <- list()

cl <- makeCluster(10, outfile="temp/outpar.txt")
registerDoParallel(cl)

n.sim <- 10000
bal.0 <- 1000

n.grid = 20

max.horizon <- 2*12
min.horizon <- 6
by.horizon <- 1

max.yield <- 0.5
min.yield <- 0.05
by.yield <- 0.025

max.total.loan <- 10000
min.total.loan <- 10000
by.total.loan <- 500

do.copy.files <- T

set.seed(seed = 10)

vec.yield <- seq(from = min.yield, to = max.yield, by = by.yield)
vec.horizon <- seq(from =min.horizon, to = max.horizon, by = by.horizon)
vec.total.loan <- seq(from = min.total.loan, to = max.total.loan, by = by.total.loan)


my.grid <- expand.grid(vec.horizon, vec.yield, vec.total.loan )
colnames(my.grid) <- c('maturity', 'yield', 'total.loan')

GetPayments <- function(R.aa =0.1,
                        N=12,
                        Loan = 5000){
  
  R <- (1+R.aa)^(1/12) -1
  p <- Loan*(R/(1-(1+R)^(-N)))
  
}

n.T <- 5*12   # number of time periods in simulated financial history
FI <- 3000
MI <-    c(rep(200,5),FI*0.5,rep(100,5),FI*(0.5 + 1/3) )
MI_se <- rep(50,12)

FE <- 2950
ME <-    c(rep(200,5),0.5*FE,rep(100,5), 0.5*FE)
ME_se <- rep(350,12)

tEmployment <- 3*12
t_no_Employment <- 3

df <- CreateFinHistory(n.T, bal.0, FI,MI,MI_se,FE,ME,ME_SE)  

i.m <- df$i.m
Income <- df$Income
Expenses <- df$Expenses

l.in <- EstimateBAR(i.m, Income,Expenses,tEmployment,t_no_Employment )

l.in$bal.0 <- bal.0

LGD.vec <- numeric()
E.R.vec <- numeric()

foreach(i.grid=1:nrow(my.grid)) %dopar% {
#for (i.grid in seq(1,nrow(my.grid))){
    
  require(dummies)
  require(markovchain)
  require(reshape2)
  require(dplyr)
  
  now.yield  <- my.grid$yield[i.grid]
  now.maturity <- my.grid$maturity[i.grid]
  now.total.loan <- my.grid$total.loan[i.grid]
  
  now.diff <- GetPayments(R.aa = now.yield, 
                          N = now.maturity, 
                          Loan = now.total.loan)
  
  l.in2 <- l.in
  l.in2$my.m.E$coefficients[1] <- l.in2$my.m.E$coefficients[1] + now.diff
  
  
  
  poup.mat <- Simulate_BAR(n.sim = n.sim,
                           n.T =  now.maturity,
                           list.in = l.in2,
                           silent=T)
  
  poup.mat <- poup.mat[-1,]
  
  #browser()
  
  default.cases <- rowMeans(matrix(as.numeric(poup.mat<=0),nrow = now.maturity ))
 
  LGD <- sum(default.cases*now.diff)
  #E.R <- sum((1-default.cases)*now.diff/now.total.loan ) 
  E.R <- sum((1-default.cases)*now.diff/now.total.loan ) 
  SD <- sd((1-default.cases)*now.diff/now.total.loan ) 
  
  temp.df <- data.frame(i.grid = i.grid, 
                        LGD = LGD, 
                        E.R = E.R, 
                        SD= SD,
                        yield = now.yield,
                        maturity = now.maturity)
  temp.f <- paste0('TxTOut/df_temp_',i.grid,'.csv')
  write.csv(x = temp.df, file = temp.f)
  #LGD.vec <- c(LGD.vec, LGD)
  #E.R.vec <- c(E.R.vec, E.R)
  
  cat('\ni.grid',' = ',i.grid, '|',nrow(my.grid),
      'now.maturity =', now.maturity, 
      'now.total.loan = ', now.total.loan,
      'now.yield = ', now.yield,
      'LGD = ', LGD)
      #'E.R = ', E.R)
  
  #browser()
  
  }

stopCluster(cl)

my.f <- dir(path = 'TxTOut', pattern = '*.csv', full.names = T)

df <- data.frame()

for (i.f in my.f){
  
  df.temp <- read.csv(i.f)
  df <- rbind(df, df.temp)
  
}

df$X <- NULL

# x11()
# p <- ggplot(data = my.grid, aes(x = maturity, y = yield, fill = E.R))
# p <- p + geom_tile()  + scale_fill_gradient(low = "white",  high = "black")
# print(p)
# 
# 
# x11()
# p <- ggplot(data = my.grid, aes(x = maturity, y = yield, fill = SD))
# p <- p + geom_tile()  + scale_fill_gradient(low = "white",  high = "black")
# print(p)
# 
# 
# x11()
# p <- ggplot(data = my.grid, aes(x = maturity, y = yield, fill = E.R/SD))
# p <- p + geom_tile() + scale_fill_gradient(low = "white",  high = "black")
# p <- p + labs(x = 'Maturity (months)', y = 'Annual yield rate') #+ geom_text(aes(label=E.R/SD), color='black') 
# print(p)

x11()
temp.min <- df[which.min(df$LGD), ]
p <- ggplot(data = df, aes(x = maturity, y = yield, fill = LGD))
p <- p + geom_tile() + scale_fill_gradient(low = "black",  high = "white")
p <- p + labs(x = 'Maturity (months)', y = 'Annual yield rate') #+ geom_text(aes(label=E.R/SD), color='black') 
p <- p +  geom_text(data = temp.min, aes(x=maturity, y=yield, label='X', color='white', size=0.5),show.legend=F) 
print(p)

ggsave('figs/Fig_GridSearch_LGD.png')

x11()
temp.max <- df[which.max(df$E.R), ]
p <- ggplot(data = df, aes(x = maturity, y = yield, fill = E.R))
p <- p + geom_tile() + scale_fill_gradient(low = "white",  high = "black")
p <- p + labs(x = 'Maturity (months)', y = 'Annual yield rate') #+ geom_text(aes(label=E.R/SD), color='black') 
p <- p +  geom_text(data = temp.max, aes(x=maturity, y=yield, label='X', color='white'),show.legend=F) 

print(p)

ggsave('figs/Fig_GridSearch_ER.png')

max.idx <- which.max(df$E.R)
min.idx <- which.min(df$LGD)

cat('\n\nMax ER = ', (df$E.R)[max.idx], 'Maturity = ', df$maturity[max.idx], df$yield[max.idx] )
cat('\n\nMin LGD = ', (df$LGD)[min.idx], 'Maturity = ', df$maturity[min.idx], df$yield[min.idx] )
                 
if (do.copy.files){
  
  my.f <- dir(pattern = '*.png', full.names = T)
  
  file.copy(from = my.f, to ='../Writing work/Paper in Latex/v.3/Figures' ,overwrite = T)
  
}

