library(ggplot2)
library(dummies)
library(markovchain)


rm(list=ls())
graphics.off()

my.d <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(my.d)

source('fcts/Fct_Simulate_BAR.R')

l.in <- list()

n.sim <- 5000
n.T <- 10*12
l.in$bal.0 <- 500

target = 20000

df <- read.csv(file = 'SimData.csv')

d.mat <- dummy(df$i.m)[ , c(2:(length(unique(df$i.m))))]

y <- df$Income
l.in$my.m.I <- summary(lm(formula = y ~ d.mat))

y <- df$Expenses
l.in$my.m.E <- summary(lm(formula = y ~ d.mat))

l.in$r <- 0.5/100 # monthly interest rate
l.in$S0 <- 'Employed' # first state (employed)

l.in$tEmployment <- 3*12  # average time employed
l.in$t_no_Employment <- 3 # average time unemployed

l.in$i.m <- df$i.m

poup.mat <- Simulate_BAR(n.sim = n.sim,
                         n.T = n.T,
                         list.in = l.in)


library(reshape)
poup.df <- melt(poup.mat)
poup.df$X2 <- as.factor(poup.df$X2)

x11()
p <- ggplot(data=poup.df, aes(x = X1, y = value, color = X2))
p <- p + geom_line(size=0.05) + theme(legend.position="none") + scale_color_manual(values=c(rep("#000000", n.sim)))
print(p)
ggsave(filename = 'Fig_BalancePath.png')


# prob of default

default.cases<- rowMeans(matrix(as.numeric(poup.mat[-1, ]<=0),nrow = n.T) )

df <- data.frame(default.cases = default.cases,
                 x = 1:n.T)

x11()
p<- ggplot(data = df, aes(x =x, y = default.cases ))
p <- p + geom_line(size=2) + labs(x = 'Months', y = 'Probability of Default')
print(p)
ggsave(filename = 'Fig_DefaultProbability.png')
