Simulate_BAR <- function(n.sim = 1000,
                         n.T = 12,
                         list.in,
                         silent = F){
  #browser()
  p11=1-1/list.in$tEmployment # transitinos prob
  p22=1-1/list.in$t_no_Employment
  
  i.m <- list.in$i.m
  
  coeff.I <- coef(list.in$my.m.I)
  coeff.E <- coef(list.in$my.m.E)
  
  pmat <- matrix(c(p11 , 1-p22 , 1-p11 ,p22),nrow = 2, ncol = 2, byrow = F)
  
  
  my.states <- c("Employed", "Unemployed")
  trans.mat <- matrix(c(p11   , 1-p11,
                        1-p22 , p22   ),
                      nrow = 2, 
                      byrow = T,
                      dimnames = list(my.states,my.states))
  
  my.mc <- new("markovchain", states = my.states, byrow = T,
               transitionMatrix = trans.mat, name = "My Transition Matrix")
  

  poup.mat <-   matrix(data = NA, nrow = n.T+1, ncol = n.sim)
  poup.mat[1,c(1:n.sim)]=list.in$bal.0
  
  for (i.sim in seq(1:n.sim)){
    
    if (!silent) cat(paste('\nSim = ',i.sim, '|',n.sim))
    
    
    St <- rmarkovchain(n = n.T, object = my.mc, t0 = list.in$S0)
    
    monthNow=1
    for (t in seq(1:n.T)){
      
      res.vec.I <- list.in$my.m.I$residuals[monthNow == i.m] 
      res.vec.E <- list.in$my.m.E$residuals[monthNow == i.m] 
      
      #browser()
      
      if (St[t]=='Employed'){

        
        if (monthNow!=1){  # because of the way i estimated model
          FCPosNow <- coeff.I[1] + coeff.I[monthNow] + sample(res.vec.I,1) 
          
        } else {
          FCPosNow <- coeff.I[1] + sample(res.vec.I,1) 
        }
        
      } else {
        
        FCPosNow=0
        
      }
      
      if (monthNow!=1){
        FCNegNow <- coeff.E[1] + coeff.E[monthNow] + sample(res.vec.E,1) 
        
      } else {
        FCNegNow <- coeff.E[1] + sample(res.vec.E,1) 
      }
      
      Bal=FCPosNow - FCNegNow
      
      #browser()
      
      poup.mat[t+1,i.sim]=poup.mat[t,i.sim]*(1+list.in$r)+Bal        
      
      #if (poup.mat[t+1,i.sim]<0) poup.mat[t+1,i.sim]=0
      
      
      monthNow=monthNow+1
      
      if (monthNow==13) monthNow=1
      #print(monthNow)
    }
    
  }
  
  return(poup.mat)
  
}

