Simulate_BAR <- function(n.sim = 1000,
                         n.T = 12,
                         list.in,
                         silent = F){
  #browser()
  p11=1-1/list.in$tEmployment # transitinos prob
  p22=1-1/list.in$t_no_Employment
  
  i.m <- list.in$i.m
  
  coeff.I <- coef(list.in$my.m.I)[ ,1]
  coeff.E <- coef(list.in$my.m.E)[ ,1]
  
  coeff.I.months.dummies <- c(0, coeff.I[2:length(coeff.I)]) # first month is 0 (omited during estimation)
  coeff.I.alpha <- coeff.I[1]
  
  coeff.E.months.dummies <- c(0, coeff.E[3:length(coeff.E)]) # first month is 0 (omited during estimation)
  coeff.E.phi <-   coeff.E[2]
  coeff.E.alpha <- coeff.E[1]
  
  
  pmat <- matrix(c(p11 , 1-p22 , 1-p11 ,p22),nrow = 2, ncol = 2, byrow = F)
  
  
  my.states <- c("Employed", "Unemployed")
  trans.mat <- matrix(c(p11   , 1-p11,
                        1-p22 , p22   ),
                      nrow = 2, 
                      byrow = T,
                      dimnames = list(my.states,my.states))
  
  my.mc <- new("markovchain", states = my.states, byrow = T,
               transitionMatrix = trans.mat, name = "My Transition Matrix")
  

  poup.mat <-   matrix(data = NA, nrow = n.T+1, ncol = n.sim)
  poup.mat[1,c(1:n.sim)]=list.in$bal.0
  
  for (i.sim in seq(1:n.sim)){
    
    if (!silent) cat(paste('\nSim = ',i.sim, '|',n.sim))
    
    
    St <- rmarkovchain(n = n.T, object = my.mc, t0 = list.in$S0)
    
    #browser()
    monthNow=1
    for (t in seq(1:n.T)){
      
      res.vec.I <- list.in$my.m.I$residuals[monthNow == i.m] 
      res.vec.E <- list.in$my.m.E$residuals[monthNow == i.m] 
      
      if (St[t]=='Employed'){

        FCPosNow <- coeff.I.alpha + coeff.I.months.dummies[monthNow] + sample(res.vec.I,1)
          
      } else {
        
        FCPosNow=0
        
      }
      
      FCNegNow <- coeff.E.alpha + coeff.E.phi*FCPosNow  + coeff.E.months.dummies[monthNow] + sample(res.vec.E, 1)
      
      Bal = FCPosNow - FCNegNow

      poup.mat[t+1,i.sim] <- poup.mat[t,i.sim]*(1+list.in$r)+Bal        
      
      if (poup.mat[t+1,i.sim]<=0) {
        poup.mat[t+1,i.sim] <- 0
      }
      
      if (poup.mat[t,i.sim]<=0) {
        poup.mat[t+1, i.sim] <- 0
      }
      
      monthNow=monthNow+1
      
      if (monthNow==13) monthNow=1
      #print(monthNow)
    }
    
  }
  
  return(poup.mat)
  
}

