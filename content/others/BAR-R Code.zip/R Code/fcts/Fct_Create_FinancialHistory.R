CreateFinHistory <- function(n.T, B.0, FI,MI,MI_se,FE,ME,ME_SE){
  
  n.sim <- 1
  
  for (i.sim in seq(n.sim)){
    
    cat('\nSimulating income and expense ',i.sim)
    
    I.mat <-   matrix(data = NA, nrow = n.T, ncol = n.sim)
    E.mat <-   matrix(data = NA, nrow = n.T, ncol = n.sim)
    B.mat <-   matrix(data = NA, nrow = n.T+1, ncol = n.sim)
    B.mat[1,c(1:n.sim)] <- B.0
    
    i.m =1
    for (i.t in seq(n.T)){
      
      I.mat[i.t,i.sim] <- FI + rnorm(1,mean = MI[i.m], sd = MI_se[i.m])
      E.mat[i.t,i.sim] <- FE + rnorm(1,mean = ME[i.m], sd = ME_se[i.m])
      
      if (i.t >1){
        B.mat[i.t,i.sim] <- B.mat[i.t-1,i.sim] + I.mat[i.t,i.sim] - E.mat[i.t,i.sim]
      } 
      
      i.m =i.m + 1
      
      if (i.m==13) i.m=1
    }
    
    
  }
  
  
  df <- data.frame(Time = seq(1,n.T), 
                   i.m = rep(1:12, n.T/12),
                   Expenses = E.mat, 
                   Income = I.mat, 
                   Balance = B.mat[c(1:n.T)])
  
  return(df)
}



