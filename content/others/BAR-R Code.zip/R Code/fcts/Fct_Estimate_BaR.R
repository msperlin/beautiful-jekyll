EstimateBAR <- function(i.m, Income,Expenses,tEmployment,t_no_Employment ){
  
  l.out <- list()
  
  d.mat <- dummy(i.m)[ , c(2:(length(unique(i.m))))]
  
  y <- Income
  l.out$my.m.I <- summary(lm(formula = y ~ d.mat))
  
  y <- Expenses
  l.out$my.m.E <- summary(lm(formula = y ~ Income + d.mat))
  
  l.out$r <- 0.5/100 # monthly interest rate
  l.out$S0 <- 'Employed' # first state (employed)
  
  l.out$tEmployment <- tEmployment  # average time employed
  l.out$t_no_Employment <- t_no_Employment # average time unemployed
  
  l.out$i.m <- df$i.m

  require(dummies)
  
  return(l.out)
  
  
}